package com.example.flutter_gmaps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
